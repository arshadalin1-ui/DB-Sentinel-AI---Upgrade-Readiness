# Real Evidence Collection Commands

Use these commands in the source/target environment and paste outputs into `evidence/raw/<engine>/`, or update `evidence/real/<engine>/evidence.json` directly.

## PostgreSQL
```bash
psql -Atc "SHOW server_version_num;"
psql -Atc "SELECT extname, extversion FROM pg_extension;"
psql -Atc "SHOW archive_mode; SHOW autovacuum; SHOW wal_level;"
psql -Atc "SELECT application_name, pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn) FROM pg_stat_replication;"
pg_upgrade --check ... > evidence/raw/postgresql/pg_upgrade_check.txt
```

## SQLite
```bash
sqlite3 app.db "PRAGMA integrity_check;"
sqlite3 app.db "PRAGMA foreign_key_check;"
sqlite3 app.db "PRAGMA journal_mode; PRAGMA page_count;"
```

## MongoDB
```bash
mongosh --quiet --eval 'db.version()'
mongosh --quiet --eval 'db.adminCommand({getParameter:1, featureCompatibilityVersion:1})'
mongosh --quiet --eval 'rs.status()'
mongosh --quiet --eval 'db.serverStatus()'
mongosh --quiet --eval 'db.getSiblingDB("admin").runCommand({listDatabases:1})'
mongosh --quiet --eval 'sh.status()'
```
Validate manually in `evidence/real/mongodb/evidence.json`: FCV, replica health, lag, backup, restore test, oplog window, auth, storage engine, indexes, slow queries, app compatibility, rollback.

## Cassandra
```bash
nodetool status > evidence/raw/cassandra/nodetool_status.txt
nodetool describecluster > evidence/raw/cassandra/describecluster.txt
nodetool info > evidence/raw/cassandra/info.txt
nodetool compactionstats > evidence/raw/cassandra/compactionstats.txt
nodetool tablestats > evidence/raw/cassandra/tablestats.txt
nodetool tpstats > evidence/raw/cassandra/tpstats.txt
nodetool netstats > evidence/raw/cassandra/netstats.txt
nodetool gossipinfo > evidence/raw/cassandra/gossipinfo.txt
```
Validate manually in `evidence/real/cassandra/evidence.json`: UP/NORMAL nodes, schema agreement, backup, restore, repair, compaction backlog, disk, dropped mutations, tombstones, native transport, driver compatibility, rollback.

## Docker
```bash
docker version > evidence/raw/docker/version.txt
docker info > evidence/raw/docker/info.txt
docker ps -a > evidence/raw/docker/containers.txt
docker images > evidence/raw/docker/images.txt
docker volume ls > evidence/raw/docker/volumes.txt
docker network ls > evidence/raw/docker/networks.txt
docker compose config > evidence/raw/docker/compose_config.txt
```

## Kubernetes
```bash
kubectl version -o yaml > evidence/raw/kubernetes/version.yaml
kubectl get nodes -o wide > evidence/raw/kubernetes/nodes.txt
kubectl get pods -A > evidence/raw/kubernetes/pods.txt
kubectl api-resources > evidence/raw/kubernetes/api_resources.txt
kubectl get crd > evidence/raw/kubernetes/crds.txt
helm list -A > evidence/raw/kubernetes/helm.txt
kubectl get all -A -o yaml > evidence/raw/kubernetes/all.yaml
```
