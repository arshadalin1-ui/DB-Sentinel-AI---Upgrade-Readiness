"""
Severity-Injection Sensitivity Study (reproduces Table V of the accompanying paper).

Constructs four controlled PostgreSQL evidence scenarios by modifying exactly
one field at a time from a healthy baseline snapshot, and runs each through
the real PostgreSQLEngine validator and scoring pipeline directly.
"""
import copy
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db_sentinel_ai.engines.postgresql import PostgreSQLEngine
from db_sentinel_ai.core.knowledge import scan_knowledge, knowledge_score
from db_sentinel_ai.core.io import count_evidence
from db_sentinel_ai.core.scoring import calculate

BASELINE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                             'evidence', 'real', 'postgresql', 'evidence.json')
KNOWLEDGE_PATHS = ['./knowledge']
SCRATCH_DIR = '/tmp/severity_injection_scratch'


def build_scenarios(base):
    scenarios = {}
    scenarios['Healthy baseline'] = copy.deepcopy(base)

    s = copy.deepcopy(base)
    s['replication'] = {'lag_bytes': 500_000_000}
    scenarios['Single HIGH (replication lag 500MB)'] = s

    s = copy.deepcopy(base)
    s['backup_status'] = {'recent_success': False}
    s['restore_tested'] = False
    scenarios['Combined CRITICAL+HIGH (backup/restore failure)'] = s

    s = copy.deepcopy(base)
    s['pg_upgrade_check'] = {'passed': False, 'blockers': ['incompatible extension: old_ext']}
    scenarios['Single CRITICAL (pg_upgrade_check failed)'] = s

    return scenarios


def run_scenario(evidence_dict):
    os.makedirs(os.path.join(SCRATCH_DIR, 'postgresql'), exist_ok=True)
    with open(os.path.join(SCRATCH_DIR, 'postgresql', 'evidence.json'), 'w') as f:
        json.dump(evidence_dict, f)
    eng = PostgreSQLEngine(SCRATCH_DIR, KNOWLEDGE_PATHS)
    evidence = eng.load_evidence()
    findings = eng.validate(evidence)
    eng.add_missing(evidence, findings)
    docs = scan_knowledge('postgresql', KNOWLEDGE_PATHS)
    kq = knowledge_score(docs)
    ec = count_evidence(evidence)
    baseline, srag, rag, risk, readiness, tvk = calculate('postgresql', ec, len(docs), kq, findings)
    return baseline, srag, rag, risk, readiness, len(findings)


def main():
    with open(BASELINE_PATH) as f:
        base = json.load(f)

    scenarios = build_scenarios(base)

    print(f"{'Scenario':<45} {'Baseline':>8} {'SRAG':>8} {'RAG':>8} {'Risk':>8} {'Readiness':>12} {'Findings':>9}")
    print('-' * 100)
    for label, evidence in scenarios.items():
        b, s, r, risk, readiness, n_findings = run_scenario(evidence)
        print(f"{label:<45} {b:>8} {s:>8} {r:>8} {risk:>8} {readiness:>12} {n_findings:>9}")

    shutil.rmtree(SCRATCH_DIR, ignore_errors=True)


if __name__ == '__main__':
    main()
