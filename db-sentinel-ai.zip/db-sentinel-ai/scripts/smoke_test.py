import subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
cmd=[sys.executable,'-m','db_sentinel_ai.cli','analyze','--config','config/default.yaml','--evidence','evidence/real','--output','output/smoke']
r=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
print(r.stdout)
if r.returncode!=0:
    print(r.stderr); raise SystemExit(r.returncode)
assert (root/'output/smoke/latest/index.html').exists()
assert (root/'output/smoke/latest/report.json').exists()
assert (root/'output/smoke/latest/engine_summary.csv').exists()
print('SMOKE TEST PASSED')
