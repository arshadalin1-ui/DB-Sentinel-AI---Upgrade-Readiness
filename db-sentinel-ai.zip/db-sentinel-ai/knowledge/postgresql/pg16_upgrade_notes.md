# PostgreSQL 16 Upgrade and Release Notes Summary

This document summarizes upgrade considerations, deprecated features, and
backup/restore requirements for PostgreSQL major version upgrades.

## pg_upgrade
Always run pg_upgrade --check before a real upgrade window. Review extension
compatibility and collation version mismatches.

## Backup and rollback
Confirm a recent verified backup and a tested restore path before upgrading.
Maintain a documented rollback procedure.

## Deprecated features
Review release notes for deprecated GUCs and removed extensions.
