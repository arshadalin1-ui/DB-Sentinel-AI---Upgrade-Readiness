# MongoDB Upgrade Runbook: featureCompatibilityVersion (FCV)

Upgrade replica set secondaries first, then the primary, before raising FCV.
Confirm replica health, oplog window, and backup status before starting the
rolling upgrade. Do not raise FCV until all members report the target binary
version. Validate application compatibility and rollback procedure.
