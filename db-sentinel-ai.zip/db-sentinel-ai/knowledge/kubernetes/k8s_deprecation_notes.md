# Kubernetes API Deprecation and Upgrade Notes

Review deprecated apiVersion usage in manifests and Helm charts before
upgrading. Confirm CRDs have backup coverage and rollback plan is tested.
