# Cassandra Rolling Upgrade Method of Procedure

Verify nodetool status shows all nodes Up/Normal and schema agreement across
the cluster before upgrade. Run repair and confirm compaction is not backlogged.
Confirm backup and restore evidence and rollback plan before proceeding.
