# Docker Engine Upgrade Notes

Confirm compose files and image tags are pinned before upgrading the Docker
engine. Backup volumes and verify rollback to previous image tags is tested.
