# SQLite Upgrade and Integrity Notes

Run PRAGMA integrity_check and foreign_key_check before any schema upgrade.
Confirm a recent file-level backup and a tested restore before proceeding.
Review journal_mode and deprecated pragma settings in release notes.
