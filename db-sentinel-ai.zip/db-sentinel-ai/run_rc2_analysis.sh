#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt
python -m db_sentinel_ai.cli analyze --config config/default.yaml --evidence evidence/real --output output/final_run
open output/final_run/latest/index.html 2>/dev/null || true
