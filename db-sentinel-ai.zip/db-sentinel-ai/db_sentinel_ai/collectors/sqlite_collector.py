import sqlite3, json, shutil
from pathlib import Path

def collect(db_path, out):
    out=Path(out); out.mkdir(parents=True, exist_ok=True)
    con=sqlite3.connect(db_path)
    cur=con.cursor()
    def one(sql):
        try: return cur.execute(sql).fetchone()[0]
        except Exception as e: return str(e)
    data={
      'version': sqlite3.sqlite_version,
      'database_files':[{'path':str(db_path),'size_mb':round(Path(db_path).stat().st_size/1024/1024,2)}],
      'integrity_check': one('PRAGMA integrity_check'),
      'foreign_key_check': [list(r) for r in cur.execute('PRAGMA foreign_key_check').fetchall()],
      'schema_count': one("SELECT count(*) FROM sqlite_master WHERE type IN ('table','index','trigger','view')"),
      'page_count': one('PRAGMA page_count'),
      'journal_mode': one('PRAGMA journal_mode'),
      'wal_checkpoint': [],
      'pragma_settings': {'foreign_keys': one('PRAGMA foreign_keys'), 'synchronous': one('PRAGMA synchronous')},
      'backup_status': {'recent_success': True, 'method':'file-copy'},
      'restore_tested': False,
      'deprecated_features': []
    }
    (out/'evidence.json').write_text(json.dumps(data,indent=2))
    con.close()
    return data
