import subprocess, json, shutil
from pathlib import Path

def run(cmd, cwd=None, timeout=30):
    try:
        r=subprocess.run(cmd, shell=True, cwd=cwd, text=True, capture_output=True, timeout=timeout)
        return {'cmd':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    except Exception as e:
        return {'cmd':cmd,'returncode':999,'stdout':'','stderr':str(e)}

def write_raw(out, name, obj):
    p=Path(out); p.mkdir(parents=True, exist_ok=True)
    (p/name).write_text(json.dumps(obj,indent=2), encoding='utf-8')
