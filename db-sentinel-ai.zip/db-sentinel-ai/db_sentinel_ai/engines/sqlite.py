
from .base import BaseEngine
from db_sentinel_ai.core.models import Finding
class SQLiteEngine(BaseEngine):
    name='sqlite'
    required=['version','database_files','integrity_check','foreign_key_check','journal_mode','schema_count','backup_status','restore_tested']
    def validate(self,e):
        f=[]
        if str(e.get('integrity_check','')).lower() != 'ok':
            f.append(Finding(self.name,'CRITICAL','integrity','SQLite integrity_check failed','PRAGMA integrity_check did not return ok.','Stop upgrade and repair/restore database first.','integrity_check'))
        fk=e.get('foreign_key_check',[])
        if fk:
            f.append(Finding(self.name,'HIGH','integrity','SQLite foreign key violations found',f'{len(fk)} violations found.','Fix FK violations before schema upgrade.','foreign_key_check'))
        if str(e.get('journal_mode','')).lower() not in ['wal','delete','truncate','persist','memory','off']:
            f.append(Finding(self.name,'MEDIUM','configuration','SQLite journal_mode unknown','Journal mode not captured or unknown.','Collect PRAGMA journal_mode before upgrade.','journal_mode'))
        if not (e.get('backup_status') or {}).get('recent_success', False):
            f.append(Finding(self.name,'HIGH','backup','SQLite backup not confirmed','No recent SQLite file backup evidence.','Create file-level backup before schema upgrade.','backup_status'))
        if not e.get('restore_tested',False):
            f.append(Finding(self.name,'MEDIUM','restore','SQLite restore test missing','Restore was not confirmed.','Restore backup to temporary path and run integrity_check.','restore_tested'))
        for d in e.get('deprecated_features',[]) or []:
            f.append(Finding(self.name,'LOW','schema',f'SQLite schema note: {d}',str(d),'Validate against schema MOP.','deprecated_features'))
        return f
