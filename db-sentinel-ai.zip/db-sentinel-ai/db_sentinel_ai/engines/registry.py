from .sqlite import SQLiteEngine
from .postgresql import PostgreSQLEngine
from .mongodb import MongoDBEngine
from .cassandra import CassandraEngine
from .docker import DockerEngine
from .kubernetes import KubernetesEngine
REGISTRY={
 'sqlite':SQLiteEngine,
 'postgresql':PostgreSQLEngine,
 'mongodb':MongoDBEngine,
 'cassandra':CassandraEngine,
 'docker':DockerEngine,
 'kubernetes':KubernetesEngine,
}
