from pathlib import Path
from typing import List
from db_sentinel_ai.core.models import Finding, EngineResult
from db_sentinel_ai.core.io import read_json, count_evidence, normalize_bool
from db_sentinel_ai.core.knowledge import scan_knowledge, knowledge_score
from db_sentinel_ai.core.scoring import calculate

class BaseEngine:
    name='base'
    required=[]
    def __init__(self, evidence_root, knowledge_paths):
        self.evidence_root=Path(evidence_root)
        self.knowledge_paths=knowledge_paths
    def load_evidence(self):
        return read_json(self.evidence_root/self.name/'evidence.json', {})
    def add_missing(self, evidence, findings):
        for key in self.required:
            if key not in evidence:
                findings.append(Finding(self.name,'MEDIUM','evidence_coverage',f'Missing evidence key: {key}',f'{key} was not present in evidence.json.','Collect the missing evidence before customer or production upgrade validation.',key))
    def validate(self, e) -> List[Finding]: return []
    def run(self):
        evidence=self.load_evidence()
        findings=self.validate(evidence)
        self.add_missing(evidence, findings)
        docs=scan_knowledge(self.name,self.knowledge_paths)
        kq=knowledge_score(docs)
        ec=count_evidence(evidence)
        b,s,r,risk,ready,tvk=calculate(self.name,ec,len(docs),kq,findings)
        recs=[f'[{f.severity}] {f.title}: {f.recommendation}' for f in findings]
        if not recs: recs=[f'{self.name}: No blocking upgrade issue found from supplied evidence. Continue with backup, restore, rollback, and application validation.']
        return EngineResult(self.name,b,s,r,risk,ready,ec,len(docs),tvk,findings,recs)
