
from .base import BaseEngine
from db_sentinel_ai.core.models import Finding
class DockerEngine(BaseEngine):
    name='docker'
    required=['version','images','containers','volumes','networks','compose_files','backup_status','rollback_tested']
    def validate(self,e):
        f=[]
        if not e.get('version'):
            f.append(Finding(self.name,'MEDIUM','evidence_coverage','Docker version missing','Docker version not captured.','Run docker version and docker info.','version'))
        if e.get('dangling_images',0)>20:
            f.append(Finding(self.name,'LOW','cleanup','Many dangling Docker images detected','Cleanup can reduce upgrade/runtime risk.','Run docker image prune after backup and approval.','dangling_images'))
        if e.get('containers_unhealthy',0)>0:
            f.append(Finding(self.name,'HIGH','runtime','Unhealthy Docker containers detected',f"containers_unhealthy={e.get('containers_unhealthy')}",'Fix unhealthy containers before Docker/runtime upgrade.','containers_unhealthy'))
        if not (e.get('backup_status') or {}).get('recent_success',False):
            f.append(Finding(self.name,'HIGH','backup','Docker volume/compose backup not confirmed','Backup evidence missing.','Backup compose files, env files, volumes, and image tags before upgrade.','backup_status'))
        if not e.get('rollback_tested',False):
            f.append(Finding(self.name,'MEDIUM','rollback','Docker rollback test missing','Rollback to previous image tags not confirmed.','Test docker compose rollback with pinned image tags.','rollback_tested'))
        return f
