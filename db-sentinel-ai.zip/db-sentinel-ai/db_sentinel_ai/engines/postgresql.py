
from .base import BaseEngine
from db_sentinel_ai.core.models import Finding
class PostgreSQLEngine(BaseEngine):
    name='postgresql'
    required=['version','server_version_num','extensions','settings','replication','pg_upgrade_check','backup_status','restore_tested','rollback_tested']
    def validate(self,e):
        f=[]
        if e.get('server_version_num',0) < 120000:
            f.append(Finding(self.name,'HIGH','version','PostgreSQL source version is old','Older source versions require extra pg_upgrade validation.','Run pg_upgrade --check and review extension and collation compatibility.','server_version_num'))
        pg=e.get('pg_upgrade_check',{})
        if pg and not pg.get('passed',False):
            f.append(Finding(self.name,'CRITICAL','upgrade_path','pg_upgrade check failed','pg_upgrade_check.passed is false.','Fix pg_upgrade blockers before upgrade window.', 'pg_upgrade_check'))
        for b in pg.get('blockers',[]) if isinstance(pg,dict) else []:
            f.append(Finding(self.name,'HIGH','upgrade_path',f'pg_upgrade blocker: {b}',str(b),'Resolve this blocker and rerun pg_upgrade --check.','pg_upgrade_check'))
        for ext in e.get('extensions',[]) or []:
            name=ext.get('name',ext) if isinstance(ext,dict) else str(ext)
            if name not in ['plpgsql']:
                f.append(Finding(self.name,'MEDIUM','extension_compatibility',f'Extension requires target compatibility confirmation: {name}','Extension package/version must exist on target PostgreSQL.','Confirm target package availability and include extension upgrade in rollback test.','extensions'))
        settings=e.get('settings',{}) or {}
        if str(settings.get('archive_mode','')).lower() not in ['on','always','true']:
            f.append(Finding(self.name,'HIGH','backup','PostgreSQL archive_mode is not enabled','Point-in-time recovery may not be safe.','Enable/validate WAL archiving or document equivalent backup strategy.','settings.archive_mode'))
        if str(settings.get('autovacuum','')).lower() not in ['on','true','1']:
            f.append(Finding(self.name,'MEDIUM','performance','PostgreSQL autovacuum is disabled','Upgrade and post-upgrade stats may be unstable.','Enable autovacuum or create manual vacuum/analyze plan.','settings.autovacuum'))
        if (e.get('replication') or {}).get('lag_bytes',0) and (e.get('replication') or {}).get('lag_bytes',0) > 104857600:
            f.append(Finding(self.name,'HIGH','replication','PostgreSQL replication lag is high','Replica lag exceeds 100MB.','Stabilize replication before upgrade or failover validation.','replication.lag_bytes'))
        if not (e.get('backup_status') or {}).get('recent_success', False):
            f.append(Finding(self.name,'CRITICAL','backup','Recent PostgreSQL backup not confirmed','No recent successful backup evidence.','Take and verify full backup before upgrade.','backup_status'))
        if not e.get('restore_tested',False):
            f.append(Finding(self.name,'HIGH','restore','PostgreSQL restore test missing','Restore validation is mandatory for production upgrade.','Run pg_restore/basebackup restore test and attach evidence.','restore_tested'))
        if e.get('deprecated_features'):
            for d in e.get('deprecated_features',[]):
                f.append(Finding(self.name,'MEDIUM','compatibility',f'Deprecated PostgreSQL feature: {d}',str(d),'Replace or validate against target release notes.','deprecated_features'))
        return f
