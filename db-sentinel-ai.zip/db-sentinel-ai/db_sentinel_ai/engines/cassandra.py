
from .base import BaseEngine
from db_sentinel_ai.core.models import Finding
class CassandraEngine(BaseEngine):
    name='cassandra'
    required=['version','target_version','nodetool_status','schema_agreement','backup_status','repair_status','compaction_status','disk_usage_percent','dropped_mutations','upgrade_path','restore_tested']
    def validate(self,e):
        f=[]
        st=e.get('nodetool_status',{}) or {}
        if st.get('down_nodes',0)>0:
            f.append(Finding(self.name,'CRITICAL','cluster_health','Cassandra DOWN nodes detected',f"down_nodes={st.get('down_nodes')}",'All nodes must be UP/NORMAL before rolling upgrade.','nodetool_status.down_nodes'))
        for k in ['joining_nodes','leaving_nodes','moving_nodes']:
            if st.get(k,0)>0:
                f.append(Finding(self.name,'HIGH','cluster_health',f'Cassandra topology change in progress: {k}',f"{k}={st.get(k)}",'Complete topology changes before upgrade.','nodetool_status'))
        if str(e.get('schema_agreement','')).lower() not in ['true','yes','1','ok']:
            f.append(Finding(self.name,'CRITICAL','schema','Cassandra schema agreement is not clean','Schema disagreement detected.','Fix schema agreement before upgrade.','schema_agreement'))
        b=e.get('backup_status',{}) or {}
        if not b.get('recent_success',False):
            f.append(Finding(self.name,'CRITICAL','backup','Cassandra snapshot/backup not confirmed','Recent backup evidence missing.','Run nodetool snapshot or enterprise backup and verify.','backup_status'))
        if not b.get('restore_tested',False) and not e.get('restore_tested',False):
            f.append(Finding(self.name,'HIGH','restore','Cassandra restore test missing','Restore validation missing.','Restore snapshot/SSTables to test cluster and validate data.','restore_tested'))
        rp=e.get('repair_status',{}) or {}
        if not rp.get('recent_success',False):
            f.append(Finding(self.name,'HIGH','repair','Cassandra recent repair not confirmed','Repair status is missing or failed.','Run/verify repair before upgrade.','repair_status'))
        cp=e.get('compaction_status',{}) or {}
        if cp.get('pending_tasks',0)>100:
            f.append(Finding(self.name,'HIGH','performance','Cassandra compaction backlog is high',f"pending_tasks={cp.get('pending_tasks')}",'Allow compaction to drain before upgrade.','compaction_status.pending_tasks'))
        if e.get('disk_usage_percent',0)>80:
            f.append(Finding(self.name,'HIGH','capacity','Cassandra disk usage is high',f"disk_usage_percent={e.get('disk_usage_percent')}",'Free disk or add capacity before upgrade; target <80%.','disk_usage_percent'))
        dm=e.get('dropped_mutations',{}) or {}
        if dm.get('total',0)>0:
            f.append(Finding(self.name,'HIGH','data_safety','Cassandra dropped mutations detected',f"total={dm.get('total')}",'Investigate dropped mutations before upgrade.','dropped_mutations.total'))
        if e.get('tombstone_warnings',0)>0:
            f.append(Finding(self.name,'MEDIUM','performance','Cassandra tombstone warnings detected',f"tombstone_warnings={e.get('tombstone_warnings')}",'Review wide partitions/tombstones before upgrade.','tombstone_warnings'))
        if str(e.get('native_transport','')).lower() not in ['enabled','true','on']:
            f.append(Finding(self.name,'HIGH','connectivity','Cassandra native transport is not enabled','Client connectivity may fail.','Enable/validate native transport and driver connectivity.','native_transport'))
        ss=e.get('sstables',{}) or {}
        if ss.get('needs_upgrade',False):
            f.append(Finding(self.name,'MEDIUM','sstable','Cassandra SSTables need upgrade','Old SSTable format detected.','Plan nodetool upgradesstables after version upgrade.','sstables.needs_upgrade'))
        up=e.get('upgrade_path',{}) or {}
        if not up.get('driver_compatibility_tested',False):
            f.append(Finding(self.name,'HIGH','compatibility','Cassandra driver compatibility test missing','Application driver compatibility not confirmed.','Test application drivers against target Cassandra version.','upgrade_path.driver_compatibility_tested'))
        if not up.get('rollback_tested',False):
            f.append(Finding(self.name,'HIGH','rollback','Cassandra rollback test missing','Rollback evidence is required.','Test snapshot restore/rollback procedure before production.','upgrade_path.rollback_tested'))
        for d in e.get('deprecated_features',[]) or []:
            f.append(Finding(self.name,'MEDIUM','compatibility',f'Deprecated Cassandra feature: {d}',str(d),'Replace or validate against target Cassandra release notes.','deprecated_features'))
        return f
