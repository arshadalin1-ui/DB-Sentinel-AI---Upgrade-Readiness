
from .base import BaseEngine
from db_sentinel_ai.core.models import Finding
class KubernetesEngine(BaseEngine):
    name='kubernetes'
    required=['version','target_version','api_versions','manifests','helm','crds','rbac','backup_status','rollback_tested']
    def validate(self,e):
        f=[]
        deprecated=e.get('deprecated_apis',[]) or []
        for api in deprecated:
            f.append(Finding(self.name,'HIGH','deprecated_api',f'Deprecated Kubernetes API detected: {api}',str(api),'Migrate manifest/Helm chart API version before cluster upgrade.','deprecated_apis'))
        if e.get('not_ready_nodes',0)>0:
            f.append(Finding(self.name,'CRITICAL','cluster_health','Kubernetes NotReady nodes detected',f"not_ready_nodes={e.get('not_ready_nodes')}",'Fix cluster health before upgrade.','not_ready_nodes'))
        if e.get('pending_pods',0)>0:
            f.append(Finding(self.name,'MEDIUM','workload','Pending pods detected',f"pending_pods={e.get('pending_pods')}",'Resolve scheduling/capacity issues before upgrade.','pending_pods'))
        if e.get('crds_without_backup',0)>0:
            f.append(Finding(self.name,'HIGH','backup','CRDs without backup detected',f"crds_without_backup={e.get('crds_without_backup')}",'Backup CRDs and custom resources before upgrade.','crds_without_backup'))
        if not (e.get('backup_status') or {}).get('recent_success',False):
            f.append(Finding(self.name,'HIGH','backup','Kubernetes backup not confirmed','Cluster/manifest backup evidence missing.','Backup etcd or manifests/Helm values before upgrade.','backup_status'))
        if not e.get('rollback_tested',False):
            f.append(Finding(self.name,'HIGH','rollback','Kubernetes rollback test missing','Rollback plan not tested.','Test Helm/app rollback and cluster recovery procedure.','rollback_tested'))
        return f
