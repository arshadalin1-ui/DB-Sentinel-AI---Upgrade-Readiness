
from .base import BaseEngine
from db_sentinel_ai.core.models import Finding
class MongoDBEngine(BaseEngine):
    name='mongodb'
    required=['version','target_version','fcv','replica_status','index_health','backup_status','oplog_window_hours','auth_enabled','storage_engine','upgrade_path','restore_tested']
    def validate(self,e):
        f=[]
        version=str(e.get('version',''))[:3]; target=str(e.get('target_version',''))[:3]; fcv=str(e.get('fcv',''))[:3]
        if target and fcv and fcv != target:
            f.append(Finding(self.name,'HIGH','version','MongoDB FCV does not match target binary version',f'FCV={fcv}, target={target}.','Align FCV only at the correct upgrade stage after replica, backup, app, and rollback tests pass.','fcv'))
        rs=e.get('replica_status',{}) or {}
        if not rs.get('primary_available', False):
            f.append(Finding(self.name,'CRITICAL','replication','MongoDB primary is not available','Replica set has no healthy primary.','Stabilize replica set before upgrade.','replica_status.primary_available'))
        if rs.get('unhealthy_members',0)>0:
            f.append(Finding(self.name,'HIGH','replication','MongoDB unhealthy replica members detected',f"unhealthy_members={rs.get('unhealthy_members')}",'Fix unhealthy members before rolling upgrade.','replica_status.unhealthy_members'))
        if rs.get('max_lag_seconds',0)>60:
            f.append(Finding(self.name,'HIGH','replication','MongoDB replication lag is high',f"max_lag_seconds={rs.get('max_lag_seconds')}",'Reduce lag before upgrade or failover testing.','replica_status.max_lag_seconds'))
        ih=e.get('index_health',{}) or {}
        if ih.get('missing_indexes',0)>0:
            f.append(Finding(self.name,'MEDIUM','performance','MongoDB missing index candidates detected',f"missing_indexes={ih.get('missing_indexes')}",'Review explain plans and create/adjust indexes before high-load upgrade testing.','index_health.missing_indexes'))
        if ih.get('unused_indexes',0)>20:
            f.append(Finding(self.name,'LOW','performance','MongoDB many unused indexes detected','Unused indexes may slow writes and upgrade checks.','Review unused indexes after upgrade testing.','index_health.unused_indexes'))
        sh=e.get('sharding_status',{}) or {}
        if sh.get('enabled') and sh.get('unbalanced_chunks',0)>0:
            f.append(Finding(self.name,'HIGH','sharding','MongoDB sharded cluster has unbalanced chunks','Chunk imbalance can increase upgrade risk.','Balance chunks before upgrade window.','sharding_status.unbalanced_chunks'))
        if not e.get('auth_enabled',False):
            f.append(Finding(self.name,'HIGH','security','MongoDB authentication is disabled','Production upgrade without auth evidence is unsafe.','Enable auth or document isolated lab exception.','auth_enabled'))
        b=e.get('backup_status',{}) or {}
        if not b.get('recent_success',False):
            f.append(Finding(self.name,'CRITICAL','backup','MongoDB recent backup not confirmed','No recent successful backup evidence.','Take mongodump/filesystem/cloud snapshot backup and verify.','backup_status'))
        if not b.get('restore_tested',False) and not e.get('restore_tested',False):
            f.append(Finding(self.name,'HIGH','restore','MongoDB restore test missing','Restore was not confirmed.','Run restore into test cluster and validate app queries.','restore_tested'))
        if e.get('oplog_window_hours',0)<24:
            f.append(Finding(self.name,'HIGH','replication','MongoDB oplog window is too small','Oplog window below 24 hours.','Increase oplog or reduce upgrade duration risk.','oplog_window_hours'))
        if e.get('storage_engine') and e.get('storage_engine')!='wiredTiger':
            f.append(Finding(self.name,'HIGH','compatibility','MongoDB storage engine requires review',f"storage_engine={e.get('storage_engine')}",'Validate target version support and migration path.','storage_engine'))
        sq=e.get('slow_queries',{}) or {}
        if sq.get('critical',0)>0:
            f.append(Finding(self.name,'HIGH','performance','Critical MongoDB slow queries detected',f"critical={sq.get('critical')}",'Fix or baseline slow queries before upgrade test.','slow_queries.critical'))
        up=e.get('upgrade_path',{}) or {}
        if not up.get('application_compatibility_tested',False):
            f.append(Finding(self.name,'MEDIUM','upgrade_path','MongoDB application compatibility test missing','Driver/query compatibility not confirmed.','Run app regression against target MongoDB version.','upgrade_path.application_compatibility_tested'))
        if not up.get('rollback_tested',False):
            f.append(Finding(self.name,'HIGH','rollback','MongoDB rollback test missing','Rollback evidence is required.','Test downgrade/restore rollback procedure before production.','upgrade_path.rollback_tested'))
        for d in e.get('deprecated_features',[]) or []:
            f.append(Finding(self.name,'MEDIUM','compatibility',f'Deprecated MongoDB feature: {d}',str(d),'Replace or validate against MongoDB target release notes.','deprecated_features'))
        return f
