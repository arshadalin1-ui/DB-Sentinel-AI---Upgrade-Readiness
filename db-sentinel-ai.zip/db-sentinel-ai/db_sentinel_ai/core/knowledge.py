from pathlib import Path
from .io import safe_text

ENGINE_ALIASES = {
    'postgresql':['PostgreSQL','postgres','pg'],
    'sqlite':['SQLite','sqlite'],
    'mongodb':['MongoDB','mongo'],
    'cassandra':['Cassandra','cassandra'],
    'docker':['Docker','docker'],
    'kubernetes':['Kubernetes','k8s','CHANGELOG'],
}
KEYWORDS = ['upgrade','release','deprecated','breaking','compatibility','backup','restore','rollback','security','index','replica','schema','sstable','featureCompatibilityVersion','FCV','pg_upgrade','helm','apiVersion']

def scan_knowledge(engine, paths):
    docs=[]
    aliases=ENGINE_ALIASES.get(engine,[engine])
    for base in paths or []:
        b=Path(base).expanduser()
        if not b.exists():
            continue
        candidates=[]
        # Prefer engine folder if exists
        for alias in aliases:
            for child in b.glob('*'):
                if alias.lower() in child.name.lower():
                    candidates.append(child)
        if not candidates:
            candidates=[b]
        for c in candidates:
            files = [c] if c.is_file() else list(c.rglob('*'))
            for f in files:
                if not f.is_file(): continue
                if f.suffix.lower() not in ['.md','.txt','.rtf','.pdf']: continue
                text=safe_text(f)
                hits=[kw for kw in KEYWORDS if kw.lower() in text.lower() or kw.lower() in f.name.lower()]
                docs.append({'path':str(f),'name':f.name,'type':f.suffix.lower().lstrip('.'),'keyword_hits':hits[:10],'size_bytes':f.stat().st_size})
    # de-dup
    seen=set(); out=[]
    for d in docs:
        if d['path'] not in seen:
            seen.add(d['path']); out.append(d)
    return out

def knowledge_score(docs):
    if not docs: return 0
    points=min(100, 35 + len(docs)*10 + sum(len(d.get('keyword_hits',[])) for d in docs)*3)
    return points
