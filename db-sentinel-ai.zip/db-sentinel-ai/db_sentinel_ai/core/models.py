from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List

@dataclass
class Finding:
    engine: str
    severity: str
    category: str
    title: str
    description: str
    recommendation: str
    evidence_key: str = ""

@dataclass
class EngineResult:
    engine: str
    baseline_score: float
    srag_score: float
    rag_score: float
    risk_score: float
    readiness: str
    evidence_count: int
    knowledge_count: int
    tvk: Dict[str, float]
    findings: List[Finding] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['findings'] = [asdict(f) for f in self.findings]
        return d
