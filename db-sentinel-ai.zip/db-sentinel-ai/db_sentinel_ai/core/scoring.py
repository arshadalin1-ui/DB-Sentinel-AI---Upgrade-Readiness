SEV={'CRITICAL':30,'HIGH':18,'MEDIUM':8,'LOW':3,'INFO':0}

def readiness(score):
    if score >= 90: return 'EXCELLENT'
    if score >= 75: return 'GOOD'
    if score >= 60: return 'CAUTION'
    return 'HIGH_RISK'

def calculate(engine, evidence_count, knowledge_count, knowledge_quality, findings):
    penalty=sum(SEV.get(f.severity,5) for f in findings)
    coverage=min(100, evidence_count*6)
    technical=max(0, 100-penalty)
    version=max(0, 96 - sum(SEV.get(f.severity,5)//2 for f in findings if f.category in ['version','compatibility','upgrade_path','deprecated_api']))
    runtime=max(0, min(100, coverage + 30) - sum(SEV.get(f.severity,5)//3 for f in findings))
    retrieved=knowledge_quality
    baseline=round(max(0, (technical*0.55 + version*0.25 + runtime*0.20) - 5),2)
    srag=round(min(100, baseline + min(7, knowledge_count*1.5 + retrieved/40)),2)
    rag=round(min(100, srag + min(12, retrieved/15)),2)
    risk=round(max(0, min(100, penalty * (1.0 if evidence_count else 1.2) - retrieved/20)),2)
    return baseline, srag, rag, risk, readiness(rag), {'technical_validation':round(technical,2),'version_compatibility':round(version,2),'retrieved_knowledge':round(retrieved,2),'runtime_evidence':round(runtime,2)}
