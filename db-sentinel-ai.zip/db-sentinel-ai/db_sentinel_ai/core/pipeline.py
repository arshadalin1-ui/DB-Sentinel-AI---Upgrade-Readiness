from datetime import datetime, timezone
from pathlib import Path
from .io import read_yaml
from db_sentinel_ai.engines.registry import REGISTRY
from db_sentinel_ai.reports.writer import write_reports

def run_pipeline(config_path, evidence_root, output_root):
    cfg=read_yaml(config_path)
    engines=cfg.get('engines') or list(REGISTRY)
    knowledge_paths=cfg.get('knowledge_paths') or ['./knowledge']
    results=[]
    for name in engines:
        cls=REGISTRY[name]
        results.append(cls(evidence_root, knowledge_paths).run())
    out=Path(output_root)/'latest'
    out.mkdir(parents=True, exist_ok=True)
    report={
      'product':cfg.get('product','DB Sentinel AI Enterprise'),
      'release':cfg.get('release','RC2-Final-Consolidated'),
      'generated_at':datetime.now(timezone.utc).isoformat(),
      'evidence_root':str(evidence_root),
      'knowledge_paths':knowledge_paths,
      'results':[r.to_dict() for r in results]
    }
    write_reports(out, report)
    return report
