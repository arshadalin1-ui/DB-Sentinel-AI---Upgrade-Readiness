import json, yaml, os, re
from pathlib import Path
from typing import Any, Dict, List

def read_yaml(path):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}

def read_json(path, default=None):
    p=Path(path)
    if not p.exists(): return {} if default is None else default
    with open(p, 'r', encoding='utf-8') as f:
        return json.load(f)

def write_json(path, data):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')

def safe_text(path):
    p=Path(path)
    try:
        if p.suffix.lower() in ['.md','.txt','.rtf']:
            return p.read_text(encoding='utf-8', errors='ignore')
        # lightweight PDF text sniff: not full OCR, but enough to detect titles/keywords in many PDFs
        if p.suffix.lower()=='.pdf':
            raw=p.read_bytes()[:2_000_000]
            return raw.decode('latin-1', errors='ignore')
    except Exception:
        return ''
    return ''

def count_evidence(obj):
    if isinstance(obj, dict): return sum(1 for k,v in obj.items() if v not in [None, '', [], {}])
    return 0

def normalize_bool(v):
    if isinstance(v, bool): return v
    if isinstance(v, str): return v.strip().lower() in ['true','yes','1','enabled','on','ok','up']
    return bool(v)
