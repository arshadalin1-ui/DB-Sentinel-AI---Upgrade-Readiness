import argparse, json, shutil
from pathlib import Path
from db_sentinel_ai.core.pipeline import run_pipeline

def init_evidence(root):
    root=Path(root)
    templates={
    'postgresql':{
      'version':'16.6','server_version_num':160006,'extensions':[{'name':'plpgsql','version':'1.0'},{'name':'postgis','version':'3.4.2'}],
      'settings':{'archive_mode':'on','autovacuum':'on','wal_level':'replica'},'replication':{'lag_bytes':0},'pg_upgrade_check':{'passed':True,'blockers':[]},
      'backup_status':{'recent_success':True,'method':'pg_dump/basebackup','last_success_utc':'2026-07-02T00:00:00Z'},'restore_tested':True,'rollback_tested':True,'deprecated_features':[]},
    'sqlite':{
      'version':'3.45.1','database_files':[{'path':'app.db','size_mb':128.4}],'integrity_check':'ok','foreign_key_check':[],'schema_count':42,'page_count':32871,'journal_mode':'wal','wal_checkpoint':[0,12,12],'pragma_settings':{'foreign_keys':1,'synchronous':2},'backup_status':{'recent_success':True,'method':'file-copy'},'restore_tested':True,'deprecated_features':[]},
    'mongodb':{
      'version':'7.0','target_version':'8.0','fcv':'7.0','replica_status':{'primary_available':True,'unhealthy_members':0,'members':3,'max_lag_seconds':5},'index_health':{'missing_indexes':1,'unused_indexes':6},'sharding_status':{'enabled':False,'unbalanced_chunks':0},'auth_enabled':True,'backup_status':{'recent_success':True,'restore_tested':True},'restore_tested':True,'oplog_window_hours':72,'storage_engine':'wiredTiger','slow_queries':{'sampled':8,'critical':0},'upgrade_path':{'source':'7.0','target':'8.0','method':'rolling','application_compatibility_tested':True,'rollback_tested':True},'deprecated_features':[]},
    'cassandra':{
      'version':'4.1.9','target_version':'5.0','nodetool_status':{'up_normal_nodes':3,'down_nodes':0,'joining_nodes':0,'leaving_nodes':0,'moving_nodes':0},'schema_agreement':'true','sstables':{'large_sstable_count':0,'needs_upgrade':False},'repair_status':{'recent_success':True},'compaction_status':{'pending_tasks':12},'dropped_mutations':{'total':0},'gc_grace_seconds':{'tables_below_policy':0},'backup_status':{'recent_success':True,'restore_tested':True},'restore_tested':True,'disk_usage_percent':68,'tombstone_warnings':0,'native_transport':'enabled','upgrade_path':{'source':'4.1.9','target':'5.0','method':'rolling','driver_compatibility_tested':True,'rollback_tested':True},'deprecated_features':[]},
    'docker':{'version':'26.x','images':12,'containers':5,'volumes':4,'networks':3,'compose_files':['docker-compose.yml'],'dangling_images':0,'containers_unhealthy':0,'backup_status':{'recent_success':True},'rollback_tested':True},
    'kubernetes':{'version':'1.31','target_version':'1.34','api_versions':['apps/v1','batch/v1'],'manifests':42,'helm':6,'crds':3,'rbac':'present','deprecated_apis':[],'not_ready_nodes':0,'pending_pods':0,'crds_without_backup':0,'backup_status':{'recent_success':True},'rollback_tested':True}}
    for eng,data in templates.items():
        d=root/eng; d.mkdir(parents=True, exist_ok=True); (d/'evidence.json').write_text(json.dumps(data,indent=2))
    print(f'Initialized evidence templates in {root}')

def main():
    ap=argparse.ArgumentParser(description='DB Sentinel AI Enterprise RC2 consolidated upgrade readiness')
    sub=ap.add_subparsers(dest='cmd')
    a=sub.add_parser('analyze'); a.add_argument('--config',default='config/default.yaml'); a.add_argument('--evidence',default='evidence/real'); a.add_argument('--output',default='output')
    i=sub.add_parser('init-evidence'); i.add_argument('--output',default='evidence/real')
    args=ap.parse_args()
    if args.cmd=='init-evidence': init_evidence(args.output); return
    if args.cmd in [None,'analyze']:
        report=run_pipeline(args.config,args.evidence,args.output)
        print('Analysis complete')
        print('Report:', str(Path(args.output)/'latest'/'index.html'))
        print('JSON:', str(Path(args.output)/'latest'/'report.json'))
        return
if __name__=='__main__': main()
