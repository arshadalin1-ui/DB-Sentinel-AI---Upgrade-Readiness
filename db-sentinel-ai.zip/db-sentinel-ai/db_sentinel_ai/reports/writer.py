import csv, json, html
from pathlib import Path

def write_reports(out, report):
    out=Path(out); out.mkdir(parents=True, exist_ok=True)
    (out/'report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    rows=[]
    for r in report['results']:
        rows.append([r['engine'],r['baseline_score'],r['srag_score'],r['rag_score'],r['risk_score'],r['readiness'],r['evidence_count'],r['knowledge_count'],len(r['findings'])])
    with open(out/'engine_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['Engine','Baseline','SRAG','RAG','Risk','Readiness','Evidence','KnowledgeDocs','Findings']); w.writerows(rows)
    total=sum(r['rag_score'] for r in report['results'])/max(1,len(report['results']))
    risk=sum(r['risk_score'] for r in report['results'])/max(1,len(report['results']))
    html_rows=''.join(f"<tr><td>{a[0]}</td><td>{a[1]}</td><td>{a[2]}</td><td>{a[3]}</td><td>{a[4]}</td><td>{a[5]}</td><td>{a[6]}</td><td>{a[7]}</td><td>{a[8]}</td></tr>" for a in rows)
    findings=[]
    for r in report['results']:
        for f in r['findings']:
            findings.append(f"<li><b>{html.escape(r['engine'])} / {html.escape(f['severity'])}</b>: {html.escape(f['title'])} - {html.escape(f['recommendation'])}</li>")
    findings_html=''.join(findings) or '<li>No findings from supplied evidence.</li>'
    content=f"""<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(report['product'])}</title>
<style>body{{font-family:Arial,sans-serif;background:#f6f8fb;margin:24px;color:#172033}}.card{{background:white;border-radius:14px;padding:20px;margin:18px 0;box-shadow:0 2px 10px #0001}}.score{{font-size:54px;font-weight:800}}table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #ddd;padding:10px;text-align:left}}th{{background:#eef2ff}}.pill{{display:inline-block;border-radius:999px;background:#e8f5e9;padding:4px 10px}}</style></head><body>
<h1>{html.escape(report['product'])} - {html.escape(report['release'])}</h1>
<div class='card'><div class='pill'>Executive Readiness</div><div class='score'>{total:.2f}</div><div>Executive Risk: {risk:.2f}</div><div>Generated: {html.escape(report['generated_at'])}</div></div>
<div class='card'><h2>Engine Summary</h2><table><tr><th>Engine</th><th>Baseline</th><th>SRAG</th><th>RAG</th><th>Risk</th><th>Readiness</th><th>Evidence</th><th>Knowledge Docs</th><th>Findings</th></tr>{html_rows}</table></div>
<div class='card'><h2>Findings & Recommendations</h2><ul>{findings_html}</ul></div>
</body></html>"""
    (out/'index.html').write_text(content, encoding='utf-8')
